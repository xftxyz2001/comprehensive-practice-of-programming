// sqrt.c
#include <math.h>
#include "sqrt.h"

double compute_sqrt(int x)
{
    return sqrt((double)x);
}
