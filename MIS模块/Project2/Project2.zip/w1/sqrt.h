// sqrt.h
#ifndef SQRT_H
#define SQRT_H

double compute_sqrt(int x);

#endif
