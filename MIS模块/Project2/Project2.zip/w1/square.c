// square.c
#include "square.h"

int square(int x)
{
    return x * x;
}
