// square.h
#ifndef SQUARE_H
#define SQUARE_H

int square(int x);

#endif
